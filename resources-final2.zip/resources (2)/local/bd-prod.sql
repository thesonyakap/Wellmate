-- Table: user_entity
CREATE TABLE user_entity
(
    id           BIGSERIAL PRIMARY KEY,
    email        VARCHAR(255) NOT NULL UNIQUE,
    name         VARCHAR(255),
    picture      VARCHAR(255),
    gender       VARCHAR(50),
    locale       VARCHAR(50),
    about        TEXT,
    timezone     VARCHAR(255),
    last_visit   TIMESTAMP,
    birthday     DATE,
    type_height  VARCHAR(50),
    type_weight  VARCHAR(50),
    weight       VARCHAR(50),
    height       VARCHAR(50),
    active_subscribe_ai TIMESTAMP,
    is_subscribe BOOLEAN DEFAULT FALSE,
    is_active    BOOLEAN DEFAULT TRUE
);

-- Table: visitor_entity
CREATE TABLE visitor_entity
(
    id           SERIAL PRIMARY KEY,
    utm_source   VARCHAR(255),
    utm_medium   VARCHAR(255),
    utm_campaign VARCHAR(255),
    utm_term     VARCHAR(255),
    utm_content  VARCHAR(255)
);

-- Table: subscriber_entity
CREATE TABLE subscriber_entity
(
    id    BIGSERIAL PRIMARY KEY,
    email VARCHAR(255) NOT NULL
);

-- Table: role_entity
CREATE TABLE role_entity
(
    id   BIGSERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL
);

-- Join Table: users_roles
CREATE TABLE users_roles
(
    user_id BIGINT REFERENCES user_entity (id),
    role_id BIGINT REFERENCES role_entity (id),
    PRIMARY KEY (user_id, role_id)
);

-- Table: post_entity
CREATE TABLE post_entity
(
    id         BIGSERIAL PRIMARY KEY,
    article    VARCHAR(255),
    short_text TEXT,
    full_text  TEXT,
    image      VARCHAR(255),
    created    DATE,
    author_id  BIGINT REFERENCES user_entity (id),
    likes      INTEGER,
    views      INTEGER DEFAULT 0
);

-- Table: tag_entity
CREATE TABLE tag_entity
(
    id   BIGSERIAL PRIMARY KEY,
    name VARCHAR(255) UNIQUE NOT NULL
);

-- Table: post_tags (many-to-many relation between post_entity and tag_entity)
CREATE TABLE post_tags
(
    post_id BIGINT REFERENCES post_entity (id),
    tag_id  BIGINT REFERENCES tag_entity (id),
    PRIMARY KEY (post_id, tag_id)
);

-- Join Table: users_likes
CREATE TABLE users_likes
(
    post_id BIGINT REFERENCES post_entity (id),
    user_id BIGINT REFERENCES user_entity (id),
    PRIMARY KEY (post_id, user_id)
);

CREATE TABLE supplement_type_entity
(
    id    BIGSERIAL PRIMARY KEY,
    name  VARCHAR(255),
    color VARCHAR(255)
);

CREATE TABLE supplement_entity
(
    id           BIGSERIAL PRIMARY KEY,
    name         VARCHAR(255),
    producer     VARCHAR(255),
    serving      VARCHAR(255),
    image        VARCHAR(255),
    description  TEXT,
    author       BIGINT REFERENCES user_entity (id),
    type         BIGINT REFERENCES supplement_type_entity (id),
    portion_type VARCHAR(255),
    is_delete BOOLEAN DEFAULT FALSE
);

CREATE TABLE entity_appeal
(
    id            BIGSERIAL primary key,
    text          TEXT,
    version       varchar(255),
    register_time TIMESTAMP,
    author        BIGINT REFERENCES user_entity (id)
);

CREATE TABLE ingredient_entity
(
    id                 BIGSERIAL PRIMARY KEY,
    name               VARCHAR(255),
    amount             INTEGER,
    value              VARCHAR(255),
    amount_weight_type VARCHAR(255),
    supplement_id      BIGINT,
    FOREIGN KEY (supplement_id) REFERENCES supplement_entity (id)
);

CREATE TABLE intake_schedule_entity
(
    id             BIGSERIAL PRIMARY KEY,
    name           TEXT,
    description    TEXT,
    color          VARCHAR(255),
    notifications  BOOLEAN DEFAULT FALSE,
    start_date     DATE,
    user_id        BIGINT,
    amount_of_days INTEGER,
    skipping_days  INTEGER,
    FOREIGN KEY (user_id) REFERENCES user_entity (id)
);

CREATE TABLE intake_event_entity
(
    id                 BIGSERIAL PRIMARY KEY,
    intake_schedule_id BIGINT,
    event_date_time    TIMESTAMP,
    FOREIGN KEY (intake_schedule_id) REFERENCES intake_schedule_entity (id)
);

CREATE TABLE intake_time_entity
(
    id                 BIGSERIAL PRIMARY KEY,
    time               TIME,
    intake_schedule_id BIGINT,
    FOREIGN KEY (intake_schedule_id) REFERENCES intake_schedule_entity (id)
);

CREATE TABLE supplement_intake_detail_entity
(
    id                 BIGSERIAL PRIMARY KEY,
    intake_schedule_id BIGINT,
    supplement_id      BIGINT,
    dosage             DOUBLE PRECISION,
    FOREIGN KEY (intake_schedule_id) REFERENCES intake_schedule_entity (id),
    FOREIGN KEY (supplement_id) REFERENCES supplement_entity (id)
);

CREATE TABLE schedule_days
(
    schedule_id  BIGINT,
    days_of_week VARCHAR(255),
    FOREIGN KEY (schedule_id) REFERENCES intake_schedule_entity (id)
);

------------------------------------
--CHAT--
------------------------------------

CREATE TABLE chat_room_entity
(
    id      SERIAL PRIMARY KEY,
    name    VARCHAR(255) NOT NULL,
    color   VARCHAR(255),
    picture INTEGER
);

CREATE TABLE user_chat_room_entity
(
    id           SERIAL PRIMARY KEY,
    user_id      INTEGER NOT NULL,
    chat_room_id INTEGER NOT NULL,
    FOREIGN KEY (user_id) REFERENCES user_entity (id),
    FOREIGN KEY (chat_room_id) REFERENCES chat_room_entity (id),
    UNIQUE (user_id, chat_room_id)
);

CREATE TABLE message_entity
(
    id           BIGSERIAL PRIMARY KEY,
    chat_room_id INTEGER   NOT NULL,
    user_id      INTEGER   NOT NULL,
    content      TEXT      NOT NULL,
    role         TEXT      NOT NULL,
    timestamp    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (chat_room_id) REFERENCES chat_room_entity (id),
    FOREIGN KEY (user_id) REFERENCES user_entity (id)
);
------------------------------------
--SPECIALIST--
------------------------------------

CREATE TABLE specialist_profile
(
    id                    BIGSERIAL PRIMARY KEY,
    image                 VARCHAR(255),
    name                  VARCHAR(255) NOT NULL,
    about                 TEXT         NOT NULL,
    is_active             BOOLEAN      NOT NULL,
    is_banned             BOOLEAN      NOT NULL,
    max_number_of_clients INT          NOT NULL,
    user_id               BIGINT       NOT NULL,
    FOREIGN KEY (user_id) REFERENCES user_entity (id)
);
CREATE TABLE specialty
(
    id                           BIGSERIAL PRIMARY KEY,
    name                         VARCHAR(255) NOT NULL,
    specialist_profile_entity_id BIGINT,
    FOREIGN KEY (specialist_profile_entity_id) REFERENCES specialist_profile (id)
);
CREATE TABLE type_of_specialist_subscription
(
    id                           BIGSERIAL PRIMARY KEY,
    cost                         DECIMAL(10, 2) NOT NULL,
    duration                     INT            NOT NULL,
    specialist_profile_entity_id BIGINT,
    FOREIGN KEY (specialist_profile_entity_id) REFERENCES specialist_profile (id)
);

CREATE TABLE user_active_specialists
(
    user_id       BIGINT NOT NULL,
    specialist_id BIGINT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES user_entity (id),
    FOREIGN KEY (specialist_id) REFERENCES specialist_profile (id)
);

CREATE TABLE user_previous_specialists
(
    user_id       BIGINT NOT NULL,
    specialist_id BIGINT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES user_entity (id),
    FOREIGN KEY (specialist_id) REFERENCES specialist_profile (id)
);

------------------------------------
--Subscriptions--
------------------------------------
CREATE TABLE specialist_subscription
(
    id                      BIGSERIAL PRIMARY KEY,
    create_time             TIMESTAMP,
    is_start                BOOLEAN,
    start                   TIMESTAMP,
    expiration_date         TIMESTAMP,
    end_time                TIMESTAMP,
    is_active               BOOLEAN,
    specialist_id           BIGINT NOT NULL,
    user_id                 BIGINT NOT NULL,
    type_of_subscription_id BIGINT NOT NULL,
    FOREIGN KEY (specialist_id) REFERENCES specialist_profile (id),
    FOREIGN KEY (user_id) REFERENCES user_entity (id),
    FOREIGN KEY (type_of_subscription_id) REFERENCES type_of_specialist_subscription (id)
);

CREATE TABLE ai_subscription
(
    id           BIGSERIAL PRIMARY KEY,
    purchase_time BIGINT,
    product_id   VARCHAR(250),
    order_id     VARCHAR(250),
    user_id      BIGINT NOT NULL
);

CREATE TABLE google_subscription_receipt_ai_entity
(
    id             BIGSERIAL PRIMARY KEY,
    order_id       VARCHAR(250),
    package_name   VARCHAR(250),
    product_id     VARCHAR(250),
    purchase_time  BIGINT,
    purchase_state INTEGER,
    purchase_token TEXT,
    quantity       INTEGER,
    auto_renewing  BOOLEAN,
    acknowledged   BOOLEAN,
    user_id        BIGINT
);
CREATE TABLE apple_subscription_receipt_ai_entity
(
    id                            SERIAL PRIMARY KEY,
    purchase_date                 DOUBLE PRECISION,
    in_app_ownership_type         VARCHAR(255),
    storefront_id                 VARCHAR(255),
    original_purchase_date        DOUBLE PRECISION,
    type                          VARCHAR(255),
    original_transaction_id       VARCHAR(255),
    product_id                    VARCHAR(255),
    subscription_group_identifier VARCHAR(255),
    storefront                    VARCHAR(255),
    environment                   VARCHAR(255),
    expires_date                  DOUBLE PRECISION,
    transaction_id                VARCHAR(255),
    quantity                      INT,
    transaction_reason            VARCHAR(255),
    web_order_line_item_id        VARCHAR(255),
    signed_date                   DOUBLE PRECISION,
    is_upgraded                   BOOLEAN,
    user_id                       BIGINT
);
CREATE TABLE apple_subscription_cancellation_entity
(
    id                            SERIAL PRIMARY KEY,
    purchase_date                 DOUBLE PRECISION,
    in_app_ownership_type         VARCHAR(255),
    storefront_id                 VARCHAR(255),
    original_purchase_date        DOUBLE PRECISION,
    type                          VARCHAR(255),
    original_transaction_id       VARCHAR(255),
    product_id                    VARCHAR(255),
    subscription_group_identifier VARCHAR(255),
    storefront                    VARCHAR(255),
    environment                   VARCHAR(255),
    expires_date                  DOUBLE PRECISION,
    transaction_id                VARCHAR(255),
    quantity                      INT,
    transaction_reason            VARCHAR(255),
    web_order_line_item_id        VARCHAR(255),
    signed_date                   DOUBLE PRECISION,
    is_upgraded                   BOOLEAN,
    revocation_date               DOUBLE PRECISION,
    revocation_reason             VARCHAR(255),
    user_id                       BIGINT
);


------------------------------------
------------------------------------

-- Inserting some data into user_entity
INSERT INTO user_entity (email, name, picture, gender, locale, last_visit, birthday, type_height, type_weight, weight,
                         height, about)
VALUES ('john.doe@example.com', 'John Doe', 'path/to/pic1', 'Male', 'en_US', NOW(), '1985-07-20', 'M', 'KG', '80',
        '180',
        'about111'),
       ('jane.doe@example.com', 'Jane Doe', 'path/to/pic2', 'Female', 'en_US', NOW(), '1990-05-15', 'M', 'KG', '80',
        '180',
        'about111'),
       ('-', 'ChatGpt3.5', 'path/to/pic1', 'Male', 'en_US', NOW(), '1985-07-20', 'FT', 'LB', '80', '180', 'about111'),
       ('--', 'System', 'path/to/pic1', 'Male', 'en_US', NOW(), '1985-07-20', 'FT', 'LB', '80', '180', 'about111'),
       ('aleksandrmon3@gmail.com', 'Alexander Kartashov', 'path/to/pic2', 'Female', 'en_US', NOW(), '1990-05-15', 'M',
        'KG', '80', '180',
        'about111'),
       ('herrschmann@gmail.com', 'Vadim', 'path/to/pic2', 'Male', 'en_US', NOW(), '1990-05-15', 'M', 'KG', '80', '180',
        'about111'),
       ('maximathmsu@gmail.com', 'Maxim', 'path/to/pic2', 'Male', 'en_US', NOW(), '1990-05-15', 'M', 'KG', '80', '180',
        'about111'),
       ('fetyukhindmitriy@gmail.com', 'Dmitriy', 'path/to/pic2', 'Male', 'en_US', NOW(), '1990-05-15', 'M', 'KG', '80',
        '180',
        'about111'),
       ('devvlad.gradskiy@gmail.com', 'Vlad', 'path/to/pic2', 'Male', 'en_US', NOW(), '1990-05-15', 'M', 'KG', '80',
        '180',
        'about111'),
       ('sanatillayevbilol@gmail.com', 'Bilol', 'path/to/pic2', 'Male', 'en_US', NOW(), '1990-05-15', 'M', 'KG', '80',
        '180',
        'about111'),
       ('vazhatsaava@gmail.com', 'Vazha', 'path/to/pic2', 'Male', 'en_US', NOW(), '1990-05-15', 'M', 'KG', '80',
        '180',
        'about111');

-- Inserting some data into role_entity
INSERT INTO role_entity (name)
VALUES ('USER'),
       ('ADMIN'),
       ('ASSISTANT'),
       ('SYSTEM'),
       ('ROLE_PREMIUM_CHAT');

-- Assign roles to users
INSERT INTO users_roles (user_id, role_id)
VALUES (1, 1), -- User John Doe has role USER
       (2, 2), -- User Jane Doe has role ADMIN
       (3, 3), -- User ChatGpt3.5 has role BOT
       (4, 4), -- User System
       (5, 2),
       (6, 2),
       (7, 2),
       (8, 2),
       (9, 2),
       (10, 2),
       (11, 2);
-- User System has role SYSTEM

-- Inserting some tags into tag_entity
INSERT INTO tag_entity (name)
VALUES ('technology'),
       ('news'),
       ('lifestyle');

-- Assuming the IDs for the tags above are 1, 2, and 3 respectively
-- and you want to link them to your posts:


-- Добавление данных в таблицу supplement_type_entity
INSERT INTO supplement_type_entity (name, color)
VALUES ('Vitamins', '#5ACD8A'),
       ('Minerals', '#5ACD8A'),
       ('Probiotics', '#5ACD8A'),
       ('Proteins', '#5ACD8A'),
       ('Amino Acids', '#5ACD8A'),
       ('Nootropics', '#5ACD8A'),
       ('Energizers', '#5ACD8A');

INSERT INTO post_entity (article, short_text, full_text, image, created, author_id, likes, views)
VALUES ('Healthy Lifestyle: Start Today!', 'Begin your journey to health today!',
        'Health is your most important wealth, and a healthy lifestyle is the key to its preservation. Learn about the steps you can take right now to improve your health and well-being. Your health largely depends on your daily habits and decisions. A healthy lifestyle includes proper nutrition, regular physical activity, attention to sleep, and many other aspects. But the main thing is the realization of the importance of taking care of your health and being ready to make changes in your life. Start small - set specific health-related goals and gradually move towards their achievement. Remember, health is a long-term investment in your future, and its worth every effort.',
        'posts/image1.png', '2023-08-01', 1, 30, 100),

       ('Nutrition and Physical Activity: The Key to Health',
        'Balance in nutrition and regular physical activity are crucial components of a healthy lifestyle.',
        'Discover how proper nutrition and an active lifestyle can make you healthier and more energetic. In this article, well discuss the role of nutrition and physical activity in maintaining your health and well-being. Healthy eating includes consuming a variety of foods rich in vitamins and minerals, as well as moderate consumption of macronutrients such as proteins, fats, and carbohydrates. Regular physical exercises will help maintain you in good physical shape, strengthen muscles, and the cardiovascular system. Always remember moderation and consistency in everything related to your lifestyle.',
        'posts/image2.png', '2023-08-02', 1, 52, 150),

       ('Dietary Supplements: A Complement to Healthy Nutrition',
        'Dietary supplements are one way to boost your health. Learn which supplements might be beneficial for you.',
        'Its not always easy to get all the necessary vitamins and minerals just from food. In this article, well discuss various dietary supplements and their role in maintaining your health. Supplements can be useful when your diet does not provide an adequate amount of certain vitamins and minerals. However, before starting any supplements, it''s essential to consult with a doctor and ensure they are safe and do not interact with your current medications.',
        'posts/image1.png', '2023-08-03', 1, 29, 120),

       ('Sleep and Its Role in Health', 'Quality sleep plays a vital role in your overall health and well-being.',
        'Learn how adhering to healthy sleep habits can improve your life. In this article, we will discuss the importance of sleep, its impact on physical and mental health, and ways to enhance your sleep. Sleep is a recovery time for your body. It helps replenish energy, renew cells, and support the immune system. Poor sleep can lead to various health issues, so its essential to give this aspect due attention.',
        'posts/image2.png', '2023-08-04', 1, 41, 180),

       ('Stress and Ways to Manage It',
        'Stress is an integral part of modern life. Learn how to manage it effectively.',
        'Modern life can be stressful, but there are ways to cope with it and maintain your health. In this article, we will talk about the nature of stress, its impact on the body, and stress management methods. Stress can affect your physical and mental health. Thus, its vital to learn how to handle it. Regular physical exercises, meditation, deep breathing, and psychotherapy are just some of the methods that can help you cope with stress.',
        'posts/image1.png', '2023-08-05', 1, 12, 90),

       ('Water - A Vital Resource',
        'Water is the foundation of your health and life. Learn why consuming enough water is so important.',
        'Water is a key element of life. In this article, we will talk about the role of water in the body, dehydration symptoms, and ways to maintain proper hydration levels. Water makes up a significant portion of your body and is involved in many processes, including thermoregulation, digestion, and toxin removal. Consuming enough water helps maintain the efficient functioning of all your body''s systems. Remember to monitor your water intake, especially in hot weather or during physical activity.',
        'posts/image2.png', '2023-08-06', 1, 32, 220),

       ('Heart Health: Disease Prevention',
        'Cardiovascular diseases are one of the leading causes of death. Learn how to prevent them.',
        'Cardiovascular diseases can be fatal, but with the right habits and health care, you can reduce risks and maintain a healthy heart. In this article, we will discuss the prevention of heart and vascular diseases. It''s important to monitor your blood pressure, cholesterol levels, and also pay attention to your lifestyle. Regular physical exercises and healthy eating are vital components for heart health.',
        'posts/image1.png', '2023-08-07', 1, 45, 110),

       ('Meditation and Relaxation: A Path to Harmony',
        'Meditation and relaxation can help you achieve harmony and mental well-being.',
        'Modern life is often filled with stress and tension. Discover how meditation and relaxation methods can help you cope with them and achieve inner harmony. Meditation is a practice that helps improve your mental and physical well-being. It allows you to reduce stress, improve concentration, and achieve deep relaxation. Regular meditation can help you understand yourself and the world around you better.',
        'posts/image2.png', '2023-08-08', 1, 29, 130),

       ('Vitamins and Minerals: Key Nutritional Elements',
        'Vitamins and minerals are essential components of your diet. Learn about their roles and sources.',
        'Proper nutrition is the key to your health, and vitamins and minerals play an important role in your diet. In this article, we will talk about the key vitamins and minerals, their roles, and sources. Vitamins and minerals are essential for the body''s normal functioning. They participate in many biochemical processes, supporting the health of the skin, hair, nails, and also organs and body systems. Find out which foods contain the necessary microelements and how to include them in your diet.',
        'posts/image1.png', '2023-08-09', 1, 60, 80),

       ('Dietary Supplements and Their Role in Maintaining Health',
        'Biologically active supplements (Dietary Supplements) can be an important addition to your diet and healthy lifestyle.',
        'In this article, we will take a closer look at biologically active supplements (Dietary Supplements) and their impact on your health. Discover which supplements can support your body and how to take them correctly. Dietary supplements can help fill the deficit of vitamins and minerals and also support the functioning of various body systems. However, it is important to use supplements wisely and on a specialist''s advice.',
        'posts/image2.png', '2023-08-10', 1, 140, 170),
       ('Why do you often get a headache when actively losing weight?',
        'Illness and headaches during weight loss worry many who are engaged in intensive weight loss. Why does this happen?', 'Reducing the percentage of fat in the body is accompanied by the release of accumulated toxic substances from this fat. Once in the bloodstream, these toxins begin to negatively affect our cells, which is why there is a general malaise, headaches and irritability. Proper detox allows you to get rid of toxins in a timely manner and feel great on your way to your ideal shape. What to do to improve detox?
        It’s all about the liver.
        The liver is the most important organ for detox. The liver processes toxins and sends them out with urine and bile. If the liver is working at half capacity or it doesn’t have enough resources to remove toxins properly, they will definitely make you feel worse and stop your weight loss progress. After all, no one wants to go to a workout when they have a headache or general malaise and weakness.
        Let’s take a deeper look at detox. It’s not that simple. The liver has two phases of detox:
        In Phase I, the liver uses various enzymes to oxidize and break down toxins.
        In Phase II, the liver converts activated toxins into water-soluble compounds that can be easily excreted from the body.
        It is very important to help the liver perform phase I properly, so that the existing accumulated toxins in the fat tissue do not harm the body. And phase II must be maintained to get rid of the converted toxins in time, because in most cases their effects are much more serious.
        What nutraceuticals can help detox?
        There are several nutraceuticals that can help support detox phases:
        Glutathione
        It helps bind and remove toxins from the body. Glutathione can be obtained from certain foods such as avocados, spinach, and celery, or used in supplement form.
        Curcumin
        This is the active ingredient in turmeric, may help stimulate phase II liver detoxification.
        Silymarin
        Silymarin supports liver health and promotes liver cell regeneration. The more cells in the liver, the more toxins it can process. It also helps strengthen the liver barrier and prevents the harmful effects of toxins.
        Green tea
        Green tea contains antioxidants that can help improve liver function and support detox.
        This small portion of nutraceuticals will help you during weight loss to support your liver and avoid headaches.
        Stay healthy with Wellmate!
        ', 'posts/image2.png', '2023-08-11', 1, 22, 80),

       ('Why is it important to maintain B vitamins in the human body?',
        'The B vitamins are eight substances: B1, B2, B3, B5, B6, B7, B9 and B12. They are involved in energy metabolism, transportation of nutrients through the body, production of red blood cells and many other functions.',
        'These vitamins are not synthesized in the body, and the stocks obtained from food are not stored for long. Therefore, it is important to regularly include in the diet their sources. Let’s understand in order, what simple and affordable products will help to maintain normal levels of B vitamins and improve our physical and mental well-being:
        🍖 B1 (thiamine)
        Plays an important role in cell growth and function, as well as breaking down nutrients for energy. Relieves depression, calms nerves, restores appetite, needed for hair growth, slows aging.
        Sources: 55% of the daily value of B1 can be obtained from just 100g of cooked pork. Slightly less than half of it comes from 100g of salmon. Other sources of thiamine: peas, fresh fruit, nuts, whole grain bread, liver
        🥛 B2 (riboflavin).
        Key component involved in cell growth, energy production and breakdown of fats, steroids and drugs. Improves sleep, relieves stress, helps the liver in detox, fights the development of hypertension.
        Sources: the main ones are milk and dairy products. A 240 ml glass of milk contains about a third of the daily allowance of B2. Riboflavin is also found in eggs, lean beef and pork, by-products, chicken breast, and salmon
        🥩 B3 (niacin)
        Used by the body to convert food, particularly sugar and fats, into energy. It’s also important for the health of the nervous and digestive systems, as well as the skin. It helps fight depression and prevents the development of pellagra.
        Sources: 109% of the daily value of B3 can be obtained from just 100g of cooked liver or other offal. And the same amount of chicken or turkey breast contains about 80% of the daily value of this vitamin.
        🐟 B5 (pantothenic acid)
        Helps break down fat and also plays an important role in the immune system. It is used in weight loss, in the treatment of eczema, asthma, bronchitis, and prevents the appearance of early gray hair and wrinkles.
        Sources: 139% of the daily value of B5 can be obtained by eating just 100 g of liver or other by-products. Other good sources of this vitamin are salmon, chicken, beef, mushrooms, milk and dairy products, and eggs
        🍗 B6 (pyridoxine)
        Performs a variety of functions including breaking down proteins, carbohydrates and fats, maintaining heart and brain health, and stimulating immunity. Reduces cramps, muscle spasms, and numbness of the extremities. It also reduces toxicosis pi pregnancy.
        Sources: 56% of the daily allowance of vitamin B6 is found in 100 g of cooked salmon, 61% in the same amount of liver, about 35% in 100 g of pork, beef or chicken
        🥚 B7 (biotin)
        Plays a vital role in helping enzymes break down fats, carbohydrates and proteins. Boosts hair and nail growth, eases muscle aches, and helps vitamin C activate the immune system.
        Sources: the record holder in biotin content is liver, 100 g of this product contains 139% of the daily value of B7. Eggs are also a good source: a large chicken egg contains about a third of the daily value of this vitamin
        What are the benefits of greens?
        🌱 B9 (folic acid)
        Helps in the production of the body’s genetic material, which is especially important during infancy, adolescence and pregnancy. Promotes the formation of quality sperm in men. Stabilizes the emotional background during the postpartum period in women. Reduces the risk of stroke and helps to heal the liver.
        Sources: 90 grams of cooked spinach has 39% of the daily value of B9, and raw spinach has a quarter more. To minimize vitamin loss due to heat processing, steam greens until soft but crunchy.
        Legumes are also rich in folic acid: depending on the variety, a half-cup serving of cooked beans contains from 12 to 60% of the daily allowance
        🦐 B12 (cyanocobalamin)
        It is essential for the formation of red blood cells and DNA. It also plays a key role in the functioning and development of the brain and nerve cells. Normalizes sleep and fights insomnia. Participates in the synthesis of hemoglobin, which is very important for the female body. Prevents the development of sclerosis and dementia.
        Sources: oysters, clams and mussels. In 100 g of these products in the finished form contains from 1000 to 4000% of the daily norm of cyanocobalamin. More vitamin B12 is rich in liver and red meat, milk, cheese, eggs
        Thus, all B vitamins ensure the normal functioning of the body from the moment of conception. Keep your diet varied for a quality and active life!
        Stay healthy with Wellmate!', 'posts/image2.png', '2023-08-12', 1, 23, 100),

       ('How to keep young?',
        'We all want to stay young and healthy for many years of our lives. While modern science is trying to create the “elixir of youth”, proper nutrition continues to play an important role in maintaining Our health. In this article, we will look at foods that can help you stay young and enjoy life for many years to come.',
        ' 1. Berries: natural antioxidants
        Berries, such as blueberries, raspberries and blueberries, are rich in antioxidants that protect the body from free radicals that contribute to aging and disease. They also contain vitamin C, which helps maintain healthy skin and immune system.
        2. Omega-3: for brain and bones
        Fish, seafood, nuts, flax seeds, chia seeds and hemp seeds are rich in omega-3 fatty acids that support brain and joint health. They also have anti-inflammatory properties, support skin health by reducing dryness and wrinkles, and help strengthen hair and nails, which supports a youthful appearance.
        3. Green vegetables: for skin and vision
        Green vegetables such as spinach, kale and broccoli are rich in vitamins, minerals and antioxidants. They help keep your skin healthy and improve your eyesight due to their high vitamin A and lutein content.
        4. Walnuts: for a healthy heart
        Walnuts are rich in polyunsaturated fatty acids, fiber and antioxidants. They help in lowering blood cholesterol levels and support heart health.
        5. Green tea: for anti-aging benefits
        Green tea contains polyphenols, which can help fight the signs of aging and strengthen bones. It can also help reduce the risk of heart disease and improve overall skin health.
        6. Oats: for healthy skin
        Oatmeal is rich in biotin, an important vitamin that helps maintain healthy skin and hair. Oatmeal is also rich in soluble fiber, which can help maintain a healthy digestive system.
        7. Avocado: for moisturizing the skin
        Avocado contains healthy fats and vitamin E, which help moisturize and protect the skin. It is also rich in folate, which helps in maintaining a healthy heart.
        8. Dark chocolate: for a good mood
        Dark chocolate is rich in antioxidants and can improve your mood as well as help reduce stress. Moderate consumption of dark chocolate can have positive effects on the heart and brain.

        Your nutrition is of utmost importance to your health and youthfulness. Incorporating these foods into your diet can help you feel better and look younger. Don’t forget about physical activity and psychological well-being — all of these combine to create the optimal conditions for staying in better shape for years to come.
        Stay healthy with Wellmate!', 'posts/image3.png', '2023-08-13', 1, 40, 120),

       ('The perfect breakfast — what is it?',
        'The first meal of the morning is the basis for productivity during the day. What should you include in your breakfast to get a boost of energy and provide your body with everything it needs?',
        ' Breakfast is first and foremost a complete meal. A muffin and coffee or a freshly squeezed juice is not the best options. A complete meal is defined by the presence of easily digestible protein, complex carbohydrates, the right fats and fiber.
         Which protein source should I choose?
         For breakfast, eggs, chicken, turkey, lean varieties of fish are ideal, and you can also safely use pate from offal.
         What about carbohydrates?
         Ideal and budget suitable for breakfast ordinary cereals: buckwheat, millet, quinoa, amaranth. But the famous oatmeal should be special — whole grain, because all the nutrients are concentrated in the oat shell. If you want something more sandwich-like, whole-grain breads are ideal
         Supplement carbohydrates and protein can and should be supplemented with enough fiber. For example, this could be a vegetable salad with leafy greens added. You can also add fruits or a cup of berries.
         Where are fats used in breakfast?
         Ghee, butter, coconut oil or other high smoke point oil can be used in making scrambled eggs.
         As a salad dressing or the salad ingredient itself can be a source of fat, such as avocado or olives, seeds or nuts.
         But whether to start your breakfast with salad, scrambled eggs or grits is up to your taste preferences. Traditionally, the sweeter part of the meal is consumed at the end. The following are breakfast options for you:
         -scrambled eggs with bacon, whole grain breads with pate and a bowl of seasonal berries
         -boiled buckwheat/quinoa with green beans, chicken
         -baked fish with wild rice and vegetable salad
         Stay healthy with Wellmate!', 'posts/image4.png', '2023-08-14', 1, 45, 118),

       ('Gaining mass and taking care of the pancreas', 'Weight gain and the pancreas. Where is the connection?', 'Few people realize the close relationship between the pancreas and protein digestion. Let’s understand this issue from a biochemical perspective and consider whether it makes sense to consume extra protein for pancreatic disorders.

         Digestion and the pancreas
         Food undergoes a complex path of processing in the human body and the pancreas is very important in this process. One of the main functions of the pancreas is to produce special enzymes that break down proteins, fats, and carbohydrates. Enzymes break down proteins into peptides and amino acids, which allows the body to digest protein from food. Protein is a large structure, peptides are pieces of protein, and amino acids are pieces of peptides.
         Where is the breakdown?
         When the pancreas malfunctions, protein cannot be digested fully, because it is not “crushed”. The disorder can result from several underlying causes:
         You have an undiagnosed pancreatic disorder. If you suspect you may have it, it is worth seeing a doctor. The most obvious symptom of the disease is pain in the abdomen and right subcostal area after eating.
         The pancreas works weakly. It is affected by poor diet, poor water balance, bad habits, excessive stress and lack of stress relief.
         A supplementary amount of protein
         Supplemental protein intake is not appropriate for any of the options described above. When contacting your doctor, be sure to tell him that your goal is to gain weight and he will take this into account when treating and planning nutrition for you. You can also stimulate the work of the pancreas yourself. To do this, you need to clean up your lifestyle step by step:
         Drink enough water
         Give up bad habits if you have them
         Learn to work with stress and properly relax
         Gaining mass for this is not only intense training, counting calories and protein, but also careful attitude to yourself and your digestion. Achieving results will be effective if you work with your body in a holistic way.
         Stay healthy with Wellmate!
         ', 'posts/image4.png', '2023-08-15', 1, 49, 109),

       ('Carbohydrate window: myth or reality?',
        'The carbohydrate window is a concept that has long generated interest and discussion among fitness enthusiasts and athletes. But does it really exist, and is it really important to close this window after a workout? Let’s get to the bottom of this question.',
        'Who introduced the concept of carbohydrate window?
         The concept of “carbohydrate window” became popular thanks to the research and practical experience of experts in the field of physiology and sports nutrition. In particular, John Iviett, an American physiologist and researcher, was instrumental in developing the concept in the 1970s. His research emphasized the importance of carbohydrates in restoring glycogen and reducing catabolism after physical activity.
         Why close the carbohydrate window after a workout?
         The idea of a carbohydrate window is based on several key aspects:
         Glycogen recovery
         During exercise, glycogen stores (a form of energy stored in the muscles and liver) are reduced. After a workout, glycogen levels can be restored with carbohydrates that are ingested.
         Protein synthesis
         Carbohydrates can increase protein synthesis. After a workout, the body needs protein for muscle growth and repair, and carbohydrates can help improve this process.
         Preventing catabolism
         Catabolism is the process of breaking down muscle proteins. Carbohydrates can help prevent this process and preserve muscle tissue.
         Improving recovery
         Carbohydrates also help reduce stress and improve the body’s overall recovery after an intense workout.
         Carbohydrate portion VS Meal intake
         A balanced post-workout meal is always beneficial, but a small increase in carbohydrates can be especially helpful when the workout was intense and prolonged.
         The bottom line is that pure carbohydrate replenishment such as carbohydrate drinks or gels can be helpful in certain situations, such as during long and intense training or competition. However, for most people ( not professional athletes) who go to the gym a couple times a week a balanced meal tailored to the intensity and type of training will be a more versatile and pragmatic approach.
         It’s important to consider your individual needs and goals, and take your workout plan into account. If your workouts are high in energy and carbohydrates, an increased amount of carbohydrates in your post-workout meal may be warranted. However, you should not overindulge in carbohydrates, especially if your goal is weight loss or blood sugar control.
         Stay heathy with Wellmate!', 'posts/image4.png', '2023-08-16', 1, 50, 122),

       ('What are the benefits of spices?',
        'Spices not only add flavor and aroma to your dishes, but also enrich them with health benefits. With a plethora of scientific studies confirming their beneficial effects on health, it’s clear: spices are not just a seasoning, but also the key to better health and overall well-being.',
        'Curcuma — Gold for Health:
         Curcuma is a spice known for its anti-inflammatory and antioxidant properties. It contains curcumin, which has been linked to reduced risk of heart disease, anti-carcinogenic properties, and improved brain function. Studies have also linked turmeric to reducing symptoms of arthritis and depression.
         Ginger — For Stomach Health and Immunity:
         Ginger is known for its properties to help reduce nausea and strengthen the stomach. Studies show that ginger can be effective in treating morning sickness in pregnant women and nausea after surgery. It also has antibacterial and antiviral properties, which helps support the immune system.
         Garlic — Heart and Antiseptic:
         Garlic contains alicin, an active ingredient with antiseptic properties. It can help lower blood pressure, cholesterol levels and the risk of heart disease. Garlic also has antiviral properties and can help fight colds.
         Pepper — Vigor and Metabolism:
         Black pepper contains piperine, a substance that promotes better absorption of other nutrients. This can help increase digestive efficiency and provide better absorption of vitamins and minerals.
         Cinnamon — Sugar Reduction and Cell Protection:
         Cinnamon can help lower blood sugar levels, which is beneficial for people with diabetes or at risk of developing it. It is also rich in antioxidants, which can protect cells from damage and promote overall health.

         In summarizing, spices not only add flavor to dishes, but they can also play an important role in keeping you healthy. Studies show that many spices have anti-inflammatory, antioxidant, and other health benefits. Incorporating a variety of spices into your diet can improve your physical and mental well-being, enrich your nutrition, and make your meals even tastier.',
        'posts/image5.png', '2023-08-17', 1, 201, 88);

-- Linking 'technology' and 'news' tags to 'First Post'
INSERT INTO post_tags (post_id, tag_id)
VALUES (1, 1), -- 'First Post' with 'technology'
       (2, 1),
       (2, 2),
       (2, 3),
       (3, 3),
       (4, 3),
       (5, 3),
       (6, 3),
       (7, 3);

-- Likes for posts
INSERT INTO users_likes (post_id, user_id)
VALUES (1, 2), -- User Jane Doe likes the first post
       (2, 1);
-- User John Doe likes the second post






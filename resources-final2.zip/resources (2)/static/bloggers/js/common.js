//(дропдауны)
const heads = document.querySelectorAll('.section__faq-item');

if(heads){
  heads.forEach(head => {
    const headTitle = head.querySelector('.section__faq-item-title');
    const headsDrop = head.querySelector('.section__faq-item-text');
    head.addEventListener('click', () => {
      head.classList.toggle('section__faq-item-active')
      headsDrop.classList.toggle('section__faq-item-text-active')
      // headTitle.classList.toggle('head__drop-title-active')

    });

    document.addEventListener('click', (e) => {
      if (!head.contains(e.target)) {
        headsDrop.classList.remove('section__faq-item-text-active');
        // headTitle.classList.remove('head__drop-title-active');
        head.classList.remove('section__faq-item-active')
      }

    });

  });
}


//решение проблемы 100vh
// function updateVH() {
//   let vh = window.innerHeight * 0.01;
//   document.documentElement.style.setProperty('--vh', `${vh}px`);
// }

// // Устанавливаем значение --vh при первоначальной загрузке
// updateVH();

// // Добавляем обработчик событий для ресайза окна
// window.addEventListener('resize', updateVH);




//мобильное меню//
// const menuIcon = document.querySelector(".menu__icon");
// const headMenu = document.querySelector(".header__nav");
// const menuItems = document.querySelectorAll(".header__nav ul li a");
// menuIcon.addEventListener("click", function (e){
//    menuIcon.classList.toggle("_active");
//    headMenu.classList.toggle("_actived");
//    document.body.classList.toggle("_lock");
// });
// menuItems.forEach(function (item) {
// item.addEventListener("click", function (e){
//    menuIcon.classList.remove("_active");
//   headMenu.classList.remove("_actived");
//    document.body.classList.remove("_lock");
// });
//  });

//якоря//

//  document.addEventListener('DOMContentLoaded', function() {
//   const links = document.querySelectorAll('a[href^="#"]');

//   links.forEach(function(link) {
//     link.addEventListener('click', function(e) {
//       e.preventDefault();

//       const targetId = this.getAttribute('href').substring(1); // Получаем id якоря
//       const targetElement = document.getElementById(targetId); // Находим элемент с этим id

//       if (targetElement) {
//         const targetPosition = targetElement.offsetTop; // Получаем его вертикальное положение
//         window.scrollTo({
//           top: targetPosition,
//           behavior: 'smooth' // Добавляем плавную прокрутку
//         });
//       }
//     });
//   });
// });

// window.addEventListener("load", function () {
//   // Обработка якорей
//   const hash = window.location.hash;
//   if (hash) {
//     const tab = document.querySelector(hash);

//     if (tab) {
//       const tabs = document.querySelectorAll(".section__objects-tab");
//       const tabContents = document.querySelectorAll(".section__objects-tab-content");
//       tabs.forEach(t => t.classList.remove('section__objects-tab-active'));
//       tabContents.forEach(content => content.classList.remove('section__objects-tab-content-active'));

//       tab.classList.add("section__objects-tab-active");

//       const tabId = tab.getAttribute('data-tab');
//       const tabContent = document.getElementById(tabId);
//       tabContent.classList.add("section__objects-tab-content-active");

//       // Прокручиваем страницу к целевому табу с учетом смещения
//       window.scrollTo(0, tab.offsetTop - 140);
//     }
//   }
// });

// document.addEventListener("DOMContentLoaded", function () {
//   // Обработка кликов по ссылкам с якорями
//   const links = document.querySelectorAll(".head__drop-ul-anchor a");
//   if(links){
//     links.forEach(link => {
//       link.addEventListener("click", function (e) {
//           e.preventDefault(); // Отменяем стандартное действие ссылки

//           const targetTabId = link.getAttribute("href").substring(1); // Убираем знак # из якоря
//           const targetTab = document.getElementById(targetTabId);

//           if (targetTab) {
//               // Убираем активный класс у всех табов и добавляем его только к целевому табу
//               document.querySelectorAll(".section__objects-tab").forEach(tab => {
//                   tab.classList.remove("section__objects-tab-active");
//               });
//               targetTab.classList.add("section__objects-tab-active");
//               const tabContents = document.querySelectorAll(".section__objects-tab-content");

//               tabContents.forEach(content => content.classList.remove('section__objects-tab-content-active'));

//               const tabId = targetTab.getAttribute('data-tab');
//               const tabContent = document.getElementById(tabId);
//               tabContent.classList.add("section__objects-tab-content-active");

//               // Прокручиваем страницу к целевому табу с учетом смещения
//               window.scrollTo(0, targetTab.offsetTop - 140);
//           }
//       });
//     });
//   }
// })



// кастомные селекты
// const customSelects = document.querySelectorAll('.custom-select');

// // Обработка каждого кастомного селекта
// customSelects.forEach(function(customSelect) {
//   const selectSelected = customSelect.querySelector('.select-selected');
//   const selectItems = customSelect.querySelector('.select-items');
//   const selectOptions = selectItems.querySelectorAll('.select-item');

//   // При клике на выбранный элемент показать/скрыть опции
//   selectSelected.addEventListener('click', function() {
//     selectItems.classList.toggle('show');
//     selectSelected.classList.add('select-selected-active');

//   });

//   // При клике на опцию обновить выбранный элемент и скрыть опции
//   selectOptions.forEach(function(option) {
//     option.addEventListener('click', function() {
//       const value = option.dataset.value;
//       selectSelected.textContent = option.textContent;
//       selectItems.classList.remove('show');
//       // Выполните нужные действия при выборе опции (например, отправка формы или обновление данных)
//       console.log('Выбрана опция: ' + value);
//     });
//   });

//   document.addEventListener('click', function(event) {
//     if (!customSelect.contains(event.target)) {
//       selectItems.classList.remove('show');
//     }
//   });
// });






//попапы
// const buttonsPopup = document.querySelectorAll("#button-order");
// const popup = document.querySelector("#popup-order");

// buttonsPopup.forEach(function (buttonPopup) {
//     buttonPopup.addEventListener("click", function () {
//     popup.classList.add("_open");
//     document.body.classList.add("lock");
//   });
// });

// popup.addEventListener("click", function (e) {
//   if (!e.target.closest(".consult-modal")) {
//     popup.classList.remove("_open");
//     document.body.classList.remove("lock");
//   }
// });

// const popupCancel = popup.querySelector(".popup__cancel");

// if (popupCancel) {
//   popupCancel.addEventListener("click", function () {
//     popup.classList.remove("_open");
//     document.body.classList.remove("lock");
//   });
// }

//свайперы//

// const swiperContainers2 = document.querySelectorAll(".section__recomend-items");

// swiperContainers2.forEach((swiperContainer2) => {
//   const swiper = new Swiper(swiperContainer2, {
//       speed: 2300, // Укажите желаемую скорость в миллисекундах
//       slidesPerView: 3,
//       spaceBetween: 52,
//       mousewheel: false,
//       grabCursor: false,
//       navigation: {
//         nextEl: ".section__recomend-nav-next",
//         prevEl: ".section__recomend-nav-prev",
//       },
//       pagination: {
//         el: ".swiper-pagination",
//         type: "bullets",
//         clickable: true,
//       },

//       autoplay:{
//           delay:3500,
//       },
//       loop:false,
//       on: {
//         init() {
//           this.el.addEventListener('mouseenter', () => {
//             this.autoplay.stop();
//           });

//           this.el.addEventListener('mouseleave', () => {
//             this.autoplay.start();
//           });
//         }
//       },
//       breakpoints: {

//         320: {
//           slidesPerView: 'auto',
//           spaceBetween: 26,
//        },
//         768: {
//           slidesPerView: 2,
//           spaceBetween: 26,
//        },
//        1160: {
//         spaceBetween: 52,
//        },


//      },

//   });
// });

// Предположим, что ваш контейнер имеет класс .my-unique-swiper
// const swiperContainer = document.querySelector(".my-unique-swiper");

// const swiper = new Swiper(swiperContainer, {
//     speed: 2300, // Укажите желаемую скорость в миллисекундах
//     slidesPerView: 3,
//     spaceBetween: 52,
//     mousewheel: false,
//     grabCursor: false,
//     navigation: {
//       nextEl: ".section__recomend-nav-next",
//       prevEl: ".section__recomend-nav-prev",
//     },
//     pagination: {
//       el: ".swiper-pagination",
//       type: "bullets",
//       clickable: true,
//     },
//     autoplay:{
//         delay:3500,
//     },
//     loop:false,
//     on: {
//       init() {
//         this.el.addEventListener('mouseenter', () => {
//           this.autoplay.stop();
//         });

//         this.el.addEventListener('mouseleave', () => {
//           this.autoplay.start();
//         });
//       }
//     },
//     breakpoints: {

//       320: {
//         slidesPerView: 'auto',
//         spaceBetween: 26,
//      },
//       768: {
//         slidesPerView: 2,
//         spaceBetween: 26,
//      },
//      1160: {
//       spaceBetween: 52,
//      },

//    },
// });



//фильтры//

// // Получение всех кастомных выпадающих селектов на странице
// const customSelects = document.querySelectorAll('.custom-select');

// // Обработка каждого кастомного селекта
// customSelects.forEach(function(customSelect) {
//   const selectSelected = customSelect.querySelector('.select-selected');
//   const selectItems = customSelect.querySelector('.select-items');
//   const selectOptions = selectItems.querySelectorAll('.select-item');


//   // При клике на выбранный элемент показать/скрыть опции
//   selectSelected.addEventListener('click', function() {
//     selectItems.classList.toggle('show');
//     customSelect.classList.toggle('custom-select-active');

//   });

//   let initialValue = selectSelected.textContent; // Сохраните начальное значение опции

//   // При клике на опцию обновить выбранный элемент и скрыть опции
//   selectOptions.forEach(function(option) {
//     option.addEventListener('click', function() {
//       const value = option.dataset.value;
//       selectSelected.textContent = option.textContent;
//       selectItems.classList.remove('show');
//       customSelect.classList.remove('custom-select-active');
//       customSelect.classList.add('custom-select-choose');
//       // Выполните нужные действия при выборе опции (например, отправка формы или обновление данных)
//       console.log('Выбрана опция: ' + value);
//     });
//   });

//   // Закрыть опции при клике вне выпадающего селекта
//   document.addEventListener('click', function(event) {
//     if (!customSelect.contains(event.target)) {
//       selectItems.classList.remove('show');
//       customSelect.classList.remove('custom-select-active');
//     }
//   });
//   const closeButton = customSelect.querySelector('.custom-select-icon');
//   closeButton.addEventListener('click', function() {
//     selectSelected.textContent = initialValue; // Восстановите начальное значение опции
//     customSelect.classList.remove('custom-select-choose'); // Уберите класс custom-select-choose
//   });
// });





//подгрузка товаров//
// const container = document.getElementById('container');
// const loadMoreButton = document.getElementById('load-more-button');
// const itemsToShow = 8; // Количество элементов для отображения изначально
// const itemsPerLoad = 6; // Количество элементов для подгрузки при каждом нажатии

// let visibleItems = itemsToShow;
// if(container){

//   function showItems() {
//     const items = container.getElementsByClassName('section__recomend-slide');
//     for (let i = 0; i < items.length; i++) {
//       if (i < visibleItems) {
//         items[i].classList.add('section__recomend-slide-visible');
//       } else {
//         items[i].classList.remove('section__recomend-slide-visible');
//       }
//     }
//   }

//   function loadMoreItems() {
//     visibleItems += itemsPerLoad;
//     if (visibleItems >= container.getElementsByClassName('section__recomend-slide').length) {
//       loadMoreButton.style.display = 'none';
//     }
//     showItems();
//   }
//     loadMoreButton.addEventListener('click', loadMoreItems);

//   showItems();

// }


// корзина скрипты
// function initializeCartScript(container) {
//   const cartItems = container.querySelectorAll('.section__busket-item');
//   const emptyCartMessage = container.querySelector('.section__busket-empty');
//   const emptyCartItog = container.querySelector('.section__busket-items-itog');
//   const blockOform = container.querySelector('.section__busket-oform');

//   // Функция для обновления итоговой цены
//   function updateTotalPrice() {
//     let totalPrice = 0;
//     cartItems.forEach((cartItem) => {
//       const countInput = cartItem.querySelector('.section__busket-item-count-input');
//       const priceSimple = cartItem.querySelector('.section__recomend-slide-descr-price-simple span');
//       const itemTotal = cartItem.querySelector('.section__busket-item-all span');

//       // Получаем числовое значение цены и количества
//       const itemPrice = parseFloat(priceSimple.textContent.replace(/\s+/g, '')); // Удаляем пробелы и символы ₽
//       const itemCount = parseInt(countInput.textContent);

//       // Проверяем, если значение счетчика меньше 1, то удаляем карточку
//       if (itemCount < 1) {
//         cartItem.remove();
//       } else {
//         // Обновляем значение суммы для текущей карточки
//         const totalItemPrice = itemPrice * itemCount;
//         itemTotal.textContent = totalItemPrice.toLocaleString(); // Выводим с пробелами
//         totalPrice += totalItemPrice;
//       }
//       if (!container.querySelector('.section__busket-item')) {
//         emptyCartMessage.classList.add('section__busket-empty-active');
//         emptyCartItog.style.display = "none";
//         blockOform.style.display = "none";
//       } else {
//         emptyCartMessage.classList.remove('section__busket-empty-active');
//       }
//     });

//     // Обновляем итоговую цену
//     const totalSpan = container.querySelector('.section__busket-items-itog-price span');
//     totalSpan.textContent = totalPrice.toLocaleString(); // Выводим с пробелами
//   }

//   // Обработчики событий для кнопок "Плюс" и "Минус"
//   cartItems.forEach((cartItem) => {
//     const plusButton = cartItem.querySelector('.section__busket-item-count-plus');
//     const minusButton = cartItem.querySelector('.section__busket-item-count-minus');
//     const deleteButton = cartItem.querySelector('.section__busket-item-delete'); // Добавляем кнопку удаления

//     plusButton.addEventListener('click', () => {
//       const countInput = cartItem.querySelector('.section__busket-item-count-input');
//       countInput.textContent = parseInt(countInput.textContent) + 1;
//       updateTotalPrice();
//     });

//     minusButton.addEventListener('click', () => {
//       const countInput = cartItem.querySelector('.section__busket-item-count-input');
//       countInput.textContent = parseInt(countInput.textContent) - 1;
//       updateTotalPrice();
//     });
//     if(deleteButton){
//       deleteButton.addEventListener('click', () => {
//         const countInput = cartItem.querySelector('.section__busket-item-count-input');
//         countInput.textContent = '0';
//         updateTotalPrice(); // Обновляем итоговую цену
//       });
//     }

//   });

//   // Инициализация итоговой цены
//   updateTotalPrice();
// }

// // Найти все контейнеры с классом 'container-for-count' и применить скрипт к каждому из них
// const containers = document.querySelectorAll('.container-for-count');
// containers.forEach((container) => {
//   initializeCartScript(container);
// });





// галерея фото и видео
// $(document).ready(function () {
//   $(".gallery a").fancybox({
//       buttons: ["slideShow", "fullScreen", "thumbs", "close"],
//   });
//   });

//   $(document).ready(function() {
//   $(".section__gallery-item-video").fancybox({
//     type: "iframe", // Указываем тип контента как iframe
//     iframe: {
//       preload: false // Отключаем предварительную загрузку iframe
//     }
//   });
// });

// видео с yt в fancy
// $(document).ready(function() {
//   $("[data-fancybox]").fancybox({
//     // Опции FancyBox
//     // Например, для воспроизведения видео внутри FancyBox:
//     iframe : {
//       css : {
//         width : '800px',
//         height : '450px'
//       }
//     }
//   });
// });

//форма//
// var forms = document.querySelectorAll('.myForm');

// if(forms){
//   forms.forEach(function(form) {
//     Inputmask("+7 (999) 999-99-99").mask("#tel");
//     var message = form.querySelector('#message');
//     const countDisplay = form.querySelector(".section__partners-form-textarea-count");
//     if(message){

//     // Добавляем обработчик события на ввод текста в поле
//     message.addEventListener("input", function() {
//       const messageLength = message.value.length;

//       // Обновляем отображение количества символов
//       countDisplay.textContent = messageLength;

//       // Проверяем, превышает ли количество символов 500
//       if (messageLength > 500) {
//           // Добавляем класс ошибки и текст ошибки
//           countDisplay.classList.add("section__partners-form-textarea-error");
//           countDisplay.textContent = "Количество символов превысило допустимое значение";
//           return; // Отменяем отправку формы
//       }
//       if (messageLength < 500) {
//           // Удаляем класс ошибки и восстанавливаем отображение количества символов
//           countDisplay.classList.remove("section__partners-form-textarea-error");
//           countDisplay.textContent = messageLength;
//       }

//     });

//     }


//     const fileInput = form.querySelector("#file");
//     const attachedFileName = form.querySelector("#attachedFileName");
//     const fileDelete = form.querySelector(".section__partners-form-input-file-delete");
//     if(fileInput){
//     // Добавляем обработчик события на выбор файла
//     fileInput.addEventListener("change", function() {
//       const fileName = fileInput.files[0].name;

//       // Вставляем имя файла в элемент span
//       attachedFileName.textContent = fileName;

//       // Добавляем класс активности
//       fileDelete.classList.add("section__partners-form-input-file-delete-active");
//   });
//     }

//     if(fileDelete){
//             // Добавляем обработчик события на клик по элементу для удаления файла
//     fileDelete.addEventListener("click", function() {
//         // Очищаем имя файла и удаляем класс активности
//         attachedFileName.textContent = "";
//         fileDelete.classList.remove("section__partners-form-input-file-delete-active");

//         // Очищаем значение в поле выбора файла
//     fileInput.value = "";
//     });
//     }



//     form.addEventListener('submit', function(event) {
//       event.preventDefault(); // Предотвращаем обычную отправку формы

//       var nameInput = form.querySelector('#name');
//       var nameInner = document.querySelector('.inner-name');
//       var nameInputErr = nameInner.querySelector('.section__partners-form-input-error');
//       var telInput = form.querySelector('#tel');
//       var telInner = document.querySelector('.inner-tel');
//       var telInputErr = telInner.querySelector('.section__partners-form-input-error');
//       var telInputErrNums = telInner.querySelector('.section__partners-form-input-error-nums');
//       var numericValue = telInput.value.replace(/\D/g, ''); // Удаляем все нецифровые символы

//       var message = form.querySelector('#message');
//       if(message){
//         const messageLength = message.value.length;
//         countDisplay.textContent = messageLength;

//         // Проверяем, превышает ли количество символов 500
//         if (messageLength > 500) {
//           alert('Сообщение слишком большое!');
//             return false; // Отменяем отправку формы

//         }
//       }

//       // Проверяем, заполнены ли обязательные поля
//       if (nameInput.value.trim() === '') {
//         nameInput.classList.add('section__partners-form-input-error-active');
//         nameInputErr.classList.add('section__partners-form-input-error-name');
//       } else {
//         nameInput.classList.remove('section__partners-form-input-error-active');
//         nameInputErr.classList.remove('section__partners-form-input-error-name');
//       }

//       // Проверяем, пустое ли поле для телефона
//       if (telInput.value.trim() === '') {
//           telInput.classList.add('section__partners-form-input-error-active');
//           telInputErr.classList.add('section__partners-form-input-error-tel');
//       } else {
//           telInput.classList.remove('section__partners-form-input-error-active');
//           telInputErr.classList.remove('section__partners-form-input-error-tel');
//       }

//       if (numericValue.length > 0 && numericValue.length < 11) {
//         telInput.classList.add('section__partners-form-input-error-active');
//          telInputErrNums.classList.add('section__partners-form-input-error-nums-active');

//      } else {
//          telInputErrNums.classList.remove('section__partners-form-input-error-nums-active');
//      }



//       nameInput.addEventListener("input", function() {
//         nameInput.classList.remove('section__partners-form-input-error-active');
//         nameInputErr.classList.remove('section__partners-form-input-error-name');
//       });
//       telInput.addEventListener("input", function() {
//         telInput.classList.remove('section__partners-form-input-error-active');
//         telInputErr.classList.remove('section__partners-form-input-error-tel');
//         telInputErrNums.classList.remove('section__partners-form-input-error-nums-active');
//        });

//        var errors = form.querySelectorAll('.section__partners-form-input-error-active');
//        if (errors.length === 0) {
//            // Если ошибок нет, выполняем отправку формы
//            alert('Форма успешно отправлена!');
//            form.reset(); // Очистка формы
//        }


//       /*var formData = new FormData(form);

//       // Выполняем AJAX-запрос
//       var xhr = new XMLHttpRequest();
//       xhr.open('POST', 'send.php'); // Укажите здесь URL обработчика на сервере
//       xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');

//       xhr.onload = function() {
//         if (xhr.status === 200) {
//           // Обработка успешного ответа
//           alert('Форма успешно отправлена!');
//           form.reset(); // Очистка формы
//         } else {
//           // Обработка ошибки
//           alert('Ошибка при отправке формы.');
//         }
//       };

//       xhr.send(formData); */
//     });
//   });
// }





//табы//
// const tabs = document.querySelectorAll('.section__card-tab');
// const tabContents = document.querySelectorAll('.section__card-tab-content');

// tabs.forEach(tab => {
//   tab.addEventListener('click', () => {

//     tabs.forEach(t => t.classList.remove('section__card-tab-active'));
//     tabContents.forEach(content => content.classList.remove('section__card-tab-content-active'));


//     tab.classList.add('section__card-tab-active');
//     const tabId = tab.getAttribute('data-tab');
//     const tabContent = document.getElementById(tabId);
//     tabContent.classList.add('section__card-tab-content-active');
//   });
// });



//карты

// if (document.querySelector('.section__card'))  {
//   function init() {
//   var myMap = new ymaps.Map("map", {
//       center: [52.002897, 113.566303], // Координаты центра карты
//       zoom: 16, // Масштаб карты
//       controls: []
//   });

//   // Создаём макет содержимого.
//   MyIconContentLayout = ymaps.templateLayoutFactory.createClass(
//       '<div style="color: #FFFFFF; font-weight: bold;">$[properties.iconContent]</div>'
//   ),

//   placemark = new ymaps.Placemark(myMap.getCenter(), {
//       balloonContentBody: '<div class="icon__content">' +
//           '<div class="icon__content-text">Забайкальский край, г. Чита, <br> ул. Агинский тракт, 22 (напротив Силикатного завода)</div>' +
//           '<a href="tel:+7(964)4650065" class="icon__content-text-tel"> +7 (964) 465 00 65</a>' +
//           '</div>'
//   });

//   myPlacemarkWithContent = new ymaps.Placemark([52.002897, 113.566303], {

//   }, {
//       // Опции.
//       // Необходимо указать данный тип макета.
//       iconLayout: 'default#imageWithContent',
//       // Своё изображение иконки метки.
//       iconImageHref: 'assets/img/geo.svg',
//       // Размеры метки.
//       iconImageSize: [40, 56],
//       // Смещение левого верхнего угла иконки относительно
//       // её "ножки" (точки привязки).
//       iconImageOffset: [-24, -40],
//       // Смещение слоя с содержимым относительно слоя с картинкой.
//       iconContentOffset: [15, 15],
//       // Макет содержимого.
//       iconContentLayout: MyIconContentLayout,
//   });



//   myMap.geoObjects
//       .add(placemark)
//       .add(myPlacemarkWithContent);
//   placemark.balloon.open();

//   }
//   ymaps.ready(init);


// }

//smooth scroll
// SmoothScroll({
//   // Время скролла 400 = 0.4 секунды
//   animationTime    : 800,
//   // Размер шага в пикселях
//   stepSize         : 75,

//   // Дополнительные настройки:

//   // Ускорение
//   accelerationDelta : 30,
//   // Максимальное ускорение
//   accelerationMax   : 2,

//   // Поддержка клавиатуры
//   keyboardSupport   : true,
//   // Шаг скролла стрелками на клавиатуре в пикселях
//   arrowScroll       : 50,

//   // Pulse (less tweakable)
//   // ratio of "tail" to "acceleration"
//   pulseAlgorithm   : true,
//   pulseScale       : 4,
//   pulseNormalize   : 1,

//   // Поддержка тачпада
//   touchpadSupport   : true,
// })




// // Создание экземпляра Rellax с настройками по умолчанию

// // Для наезда второй секции на первую
// var rellax= new Rellax('.parallax-section', {
//   speed: -8 // Экспериментируйте с этим значением для достижения нужного эффекта
// });


//аккордеон//
  // const accordionItems = document.querySelectorAll('.section__faq-item');


  // accordionItems.forEach(item => {
  //   const titleInner = item.querySelector('.section__faq-item-title-inner');
  //   const subtitle = item.querySelector('.section__faq-item-answer');

  //   titleInner.addEventListener('click', () => {

  //     subtitle.classList.toggle('section__faq-item-answer-active');
  //     titleInner.classList.toggle('section__faq-item-title-inner-active');
  //   });
  // });


//выравнивание карточек//
//  var goodsList = document.querySelector('.section__cases-items'); // Выбираем элемент с идентификатором #goods-list
// if(goodsList){
//   var cards = goodsList.querySelectorAll('.section__cases-item-main'); // Используем его для поиска карточек товаров внутри него

//     function equalizeCardHeights() {
//       var maxHeight = 0;

//       // Сброс высоты карточек, чтобы правильно измерить их естественную высоту
//       cards.forEach(function(card) {
//           card.style.height = 'auto';
//       });

//       // Находим максимальную высоту среди карточек
//       cards.forEach(function(card) {
//           if (card.offsetHeight > maxHeight) {
//               maxHeight = card.offsetHeight;
//           }
//       });

//       // Устанавливаем максимальную высоту для всех карточек
//       cards.forEach(function(card) {
//           card.style.height = maxHeight + 'px';
//       });
//     }

//     // Вызываем функцию при загрузке страницы
//     window.onload = equalizeCardHeights;

//     // Вызываем функцию при изменении размера окна, чтобы учесть возможные изменения в макете
//     window.onresize = equalizeCardHeights;


// }



//slick js

// var $slider = $(".section__history-tabs-swiper");

// // Инициализируем слайдер только если найден хотя бы один элемент
// $slider.slick({
//     arrows: false,
//     dots: false,
//     infinite: false,
//     speed: 1200,
//     slidesToShow: 4,
//     slidesToScroll: 1,
//     vertical: true,
//     draggable: true,
//     swipe: false,
//     easing: "linear",
//     centerMode: false,
//     touchMove: false,
//     waitForAnimate: true,
//     fade: false,
//     verticalSwiping: true,
//     variableWidth: false,
//     adaptiveHeight: true,
//     initialSlide: 1,
//     responsive: [
//         {
//             breakpoint: 768,
//             settings: "unslick",
//         },
//     ],
// });

//flickity js
// $(".section__history-tabs-swiper").flickity({
//   // options
//   cellAlign: "center",
//   contain: true,
//   prevNextButtons: false,
//   pageDots: false,
//   wrapAround: false,
//   draggable: true,
//   freeScroll: false,
//   // freeScrollFriction: 0.5,
//   selectedAttraction: 0.01,
//   friction: 0.3

// });

//залипание блока снизу
// function moveBlock () {
// 	if (block = document.getElementById('block')) {
// 		if (block.clientHeight > window.innerHeight) {
// 			block.style = 'top: calc(100vh - ' + block.clientHeight + 'px)';
// 		}
// 	}
// }

// moveBlock();
// window.onload = function() {
// 	moveBlock();
// };
// window.addEventListener('resize', function(event) {
// 	moveBlock();
// }, true);
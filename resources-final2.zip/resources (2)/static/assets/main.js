function onEntry(entry) {
	entry.forEach(change => {
		if (change.isIntersecting) {
			change.target.classList.add('show')
		}
	})
}

let options = { threshold: [0.5] }
let observer = new IntersectionObserver(onEntry, options)
let elements = document.querySelectorAll('.anim')
for (let elm of elements) {
	observer.observe(elm)
}

window.addEventListener('DOMContentLoaded', function () {
	var video = document.querySelector('.video-holder')

	video.addEventListener('click', function () {
		if (video.classList.contains('ready')) {
			return
		}
		video.classList.add('ready')
		var src = video.dataset.src
		video.insertAdjacentHTML(
			'afterbegin',
			'<iframe src="' +
				src +
				'" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>'
		)
	})
})
